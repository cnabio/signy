VERSION = "foo-v1"

print("Hello in-toto")

something evil
